<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Kusha</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <!--[if lte IE 8]>
    <script src="js/html5shiv.js"></script><![endif]-->
    <script src="js/jquery.min.js"></script>
    <script src="js/skel.min.js"></script>
    <script src="js/skel-layers.min.js"></script>
    <script src="js/init.js"></script>
    <noscript>
        <link rel="stylesheet" href="css/skel.css"/>
        <link rel="stylesheet" href="css/style.css"/>
        <link rel="stylesheet" href="css/style-xlarge.css"/>
    </noscript>
</head>
<body class="landing">

<!-- Header -->
<header id="header">
    <h1 class="logo"><a href="/">K<span>u</span>sha</a></h1>
    <nav id="nav">
        <ul>
            <li><img src="images/flag.png" class="flag"></li>
            <li><a href="/">Home</a></li>
            <li><a href="/about">About</a></li>
            <li><a href="mailto:hello@kusha.io">Contact</a></li>
            <li><a href="#howitworks">How it Works</a></li>
        </ul>
    </nav>
    <!-- Facebook Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
                n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window,document,'script',
                'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '460609380793016');
        fbq('track', 'PageView');
    </script>
    <noscript>
        <img height="1" width="1"
             src="https://www.facebook.com/tr?id=460609380793016&ev=PageView
&noscript=1"/>
    </noscript>
    <!-- End Facebook Pixel Code -->
</header>

<!-- Banner -->
<section id="banner">

    <div class="container">
        <div class="row">
            <img src="images/flag.png" class="flag_mobile">
            <div class="6u 12u$(medium)">
                <h1 class="logo mobile"><a href="/">K<span>u</span>sha</a></h1>
                <h2>Kusha is a free, independent service to help you find the cheapest way to send mobile money in
                    Tanzania
                </h2>
            </div>
            <div class="6u 12u$(medium)" id="input-box-id">
                <form class="input-box form1">
                    <div class="row uniform">
                        <div class="12u 12u$(small)">
                            <h3>Transfer details</h3>
                        </div>
                        <div class="12u$" style="display: flex;">
                            <span class="tsh">Tsh</span>
                            <input name="amount" id="amount" value="" placeholder="Amount"
                                   type="number" min="0"
                                   required="required" />
                        </div>
                        <div class="12u$">
                            <div class="select-wrapper">
                                <select name="option" id="option" required="required">
                                    <option value="" disabled selected hidden>Compare:</option>
                                    <option value="transfer-only">Transfer Only</option>
                                    <option value="cashout-only">Cash Out Only</option>
                                    <option value="transfer-and-cashout">Transfer and Cash Out</option>
                                </select>
                            </div>
                        </div>
                        <div class="12u$" id="provider_wrapper">
                            <div class="select-wrapper">
                                <select name="provider" id="provider" required="required">
                                    <option value="" disabled selected hidden>Your Provider</option>
                                    @foreach($providers as $item)
                                        <option value={{$item->id}}>{{$item->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="12u$" id="recipient_wrapper">
                            <div class="select-wrapper">
                                <select name="recipient" id="recipient" required="required">
                                    <option value="" disabled selected hidden>Recipient Provider</option>
                                    @foreach($providers as $item)
                                        <option value={{$item->id}}>{{$item->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row uniform" style="margin-top: 0.75em;">
                        <div class="12u 12u$">
                            <input value="Next" class="fit" type="submit">
                        </div>
                    </div>
                </form>
                <form class="input-box form2">
                    <div class="row uniform">
                        <div class="12u 12u$(small)">
                            <h4>Do you think you are using the cheapest provider?</h4>
                        </div>
                        <div class="3u 12u$(3)">
                            <input type="radio" id="is-cheapest-yes" value="yes" name="is-cheapest" required="required" />
                            <label for="is-cheapest-yes">Yes</label>
                        </div>
                        <div class="3u 12u$(3)">
                            <input type="radio" id="is-cheapest-no" value="no" name="is-cheapest">
                            <label for="is-cheapest-no">No</label>
                        </div>
                        <div class="6u$ 12u$(3)">
                            <input type="radio" id="is-cheapest-maybe" value="notsure" name="is-cheapest">
                            <label for="is-cheapest-maybe">Not Sure</label>
                        </div>
                    </div>
                    <div class="row uniform options" id="yes-options">
                        <div class="12u 12u$(small)">
                            <h4>How do you know this is the cheapest provider?</h4>
                        </div>
                        <div class="12u 12u$(3)">
                            <input type="radio" id="yes-1" name="reason" value="compared_tariff_agent" required="required" />
                            <label for="yes-1">I compared the tariff boards at the agent</label>
                        </div>
                        <div class="12u 12u$(3)">
                            <input type="radio" id="yes-2" name="reason" value="compared_tariff_website">
                            <label for="yes-2">I compared the tariffs on the providers’ websites</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="yes-3" name="reason" value="family_friends_told">
                            <label for="yes-3">My family/friends told me</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="yes-4" name="reason" value="assume">
                            <label for="yes-4">I assume it is the cheapest</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="yes-5" name="reason" value="other">
                            <label for="yes-5"><input type="text" name="other_yes" class="other"
                                                      placeholder="Other"></label>
                        </div>
                    </div>
                    <div class="row uniform options" id="no-options">
                        <div class="12u 12u$(small)">
                            <h4>What stops you from using the cheapest provider?</h4>
                        </div>
                        <div class="12u 12u$(3)">
                            <input type="radio" id="no-1" name="reason" value="family_friends_use" required="required" />
                            <label for="no-1">Family/friends use my main provider</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="no-2" name="reason" value="want_to_keep_phone">
                            <label for="no-2">I want to keep my phone number</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="no-3" name="reason" value="trust_current_provider">
                            <label for="no-3">I trust my current provider more than the other providers</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="no-4" name="reason" value="use_other_services">
                            <label for="no-4">I use other services of my current provider</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="no-5" name="reason" value="other">
                            <label for="no-5"><input type="text" name="other_no" class="other"
                                                     placeholder="Other"></label>
                        </div>
                    </div>
                    <div class="row uniform options" id="maybe-options">
                        <div class="12u 12u$(small)">
                            <h4>Why are you not sure?</h4>
                        </div>
                        <div class="12u 12u$(3)">
                            <input type="radio" id="maybe-1" name="reason" value="dont_understand" required="required">
                            <label for="maybe-1">I don’t understand the costs/prices</label>
                        </div>
                        <div class="12u 12u$(3)">
                            <input type="radio" id="maybe-2" name="reason" value="never_seen_costs">
                            <label for="maybe-2">I’ve never seen the costs/prices</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="maybe-3" name="reason" value="prices_keep_changing">
                            <label for="maybe-3">The prices keep changing</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="maybe-4" name="reason" value="dont_care_enough">
                            <label for="maybe-4">I don’t care enough to compare</label>
                        </div>
                        <div class="12u$ 12u$(3)">
                            <input type="radio" id="maybe-5" name="reason" value="other">
                            <label for="maybe-5"><input type="text" name="other_notsure" class="other"
                                                        placeholder="Other"></label>
                        </div>
                    </div>
                    <div class="12u$">
                        <input value="Get Results" class="fit" style="margin-top: 40px; display: none" id="get_results"
                               type="submit">
                    </div>
                </form>
                <div class="input-box results">
                    <div class="loader">
                        <img src="images/ring.gif" width="100px">
                    </div>
                    <div class="display">
                        <h1 id="message"></h1>
                        <div class="table">
                            <table id="comparison_table">
                            </table>
                        </div>
                        <h4 class="align-center" id="selection"></h4>
                        <div class="row uniform">
                            <div class="12u 12u$">
                                <span class="disclaimer">All prices are for sending to registered users</span>
                                <a href="/"><input value="Try Again" class="fit" type="submit"></a>
                            </div>
                            <div class="12u 12u$">
                                <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FKusha.io&width=450&layout=standard&action=like&size=small&show_faces=true&share=true&height=80&appId=233346106699160"
                                        width="100%" height="80" style="border:none;overflow:hidden" scrolling="no"
                                        frameborder="0" allowTransparency="true"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- How it works -->
<section id="one" class="wrapper style1 special">
    <div class="container">
        <header class="major">
            <h2 id="howitworks">How it Works</h2>
        </header>
        <div class="row 150%">
            <div class="4u 12u$(medium)">
                <section class="box">
                    <i class="icon big rounded color-blue fa-file"></i>

                    <p>Kusha is a free and independent service. Please enter some simple details to allow us to
                        calculate the cost of your mobile money transfer.
                    </p>
                </section>
            </div>
            <div class="4u 12u$(medium)">
                <section class="box">
                    <i class="icon big rounded color-blue fa-calculator"></i>

                    <p>We will calculate how much the transfer will cost with each provider, allowing you to
                        compare.</p>
                </section>
            </div>
            <div class="4u$ 12u$(medium)">
                <section class="box">
                    <i class="icon big rounded color-blue fa-table"></i>

                    <p>We will show you the transfer and cash-out costs using each provider, and how much you could
                        save. </p>
                </section>
            </div>
            <p>Kusha is a free and independent tool started by two friends tired of overpaying for money transfers in
                <b>Tanzania</b>. We are not affiliated with any mobile money service, bank or telecommunications
                company. All of the data presented is through our own research. We apologize if we have made any errors
                and would appreciate your feedback. For more information about us, please visit our <a href="about">About</a>
                page
            </p>
        </div>

    </div>
</section>

<!-- Footer -->
<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="12u$">
                <ul class="icons">
                    <li>
                        <a class="icon rounded fa-facebook" href="https://www.facebook.com/Kusha.io"
                           target="_blank"><span class="label">Facebook</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-91408261-1', 'auto');
    ga('send', 'pageview');

</script>
</body>
</html>
