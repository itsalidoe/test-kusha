<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Kusha</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <!--[if lte IE 8]>
    <script src="js/html5shiv.js"></script><![endif]-->
    <script src="js/jquery.min.js"></script>
    <script src="js/skel.min.js"></script>
    <script src="js/skel-layers.min.js"></script>
    <script src="js/init.js"></script>
    <noscript>
        <link rel="stylesheet" href="css/skel.css"/>
        <link rel="stylesheet" href="css/style.css"/>
        <link rel="stylesheet" href="css/style-xlarge.css"/>
    </noscript>
</head>
<body class="landing">
<!-- Header -->
<header id="header">
    <h1 class="logo"><a href="/">K<span>u</span>sha</a></h1>
    <nav id="nav">
        <ul>
            <li><img src="images/flag.png" class="flag"></li>
            <li><a href="/">Home</a></li>
            <li><a href="#" class="active">About</a></li>
            <li><a href="mailto:hello@kusha.io">Contact</a></li>
            <li><a href="/#howitworks">How it Works</a></li>
        </ul>
    </nav>
    <!-- Facebook Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
                n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window,document,'script',
                'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '460609380793016');
        fbq('track', 'PageView');
    </script>
    <noscript>
        <img height="1" width="1"
             src="https://www.facebook.com/tr?id=460609380793016&ev=PageView
&noscript=1"/>
    </noscript>
    <!-- End Facebook Pixel Code -->
</header>
<section id="banner_short">
</section>
<section id="one" class="wrapper">
    <div class="container">
        <h2>Kusha allows customers to compare Mobile Financial Services for free</h2>
        <p>Kusha is an independent initiative. We are not affiliated with any mobile money service, bank, or telecommunications company.
        </p>
        <p class="strong">The Inspiration</p>
        <p>Mobile money has brought about a number of great opportunities within Africa, especially in Tanzania. In many
            ways, financial technology in this country is far more advanced than in North America and Europe.
            Nonetheless, there are some problems that need to be addressed. When we first started doing some research
            with the World Bank, we noticed the lack of transparency when it came to mobile money fees for the average
            Tanzanian. Providers were not open about the costs to send and receive money, making it hard for people to
            understand this market. That is why we started Kusha.
        </p>
        <p>Kusha is a tool to help you quickly and easily understand the cost of sending mobile money, and which
            provider is cheapest. No more checking tariff boards or contacting call agents. No more surprises in your
            bills. Know how much you are going to pay for the transfer and cash out, with all major providers, before
            you transact.
        </p>
        <p>Mobile money services are going to change the world. Mobile money is already in 93 countries with over 271
            providers. Our goal is to start with Tanzania, but we aim to make it easy for anyone, anywhere to understand
            their financial costs with these new services. We also have big plans to help consumers choose other mobile
            financial services too. We love mobile money, and in Tanzania, we know you love it too!
        </p>
        <p>Our team includes competition policy experts, regulators and technology entrepreneurs. We are also
            part of a San Francisco based accelerator, which has previously fostered mobile technology solutions around
            the world. Contact us at any time for questions, feedback, or ideas!
        </p>

        <p class="strong">Mobile money around the world</p>
        <ul>
            <li>Mobile money providers process an average of 33 million transactions per day, that’s 11.2
                transactions
                per user per month.
            </li>
            <li>Mobile money is a key driver of financial inclusion - mobile money services are available in 85% of
                countries where less than 20% of the population has a bank account.
            </li>
            <li>In nearly 90% of markets where mobile money is live, most people will have a smartphone by 2020.
            </li>
        </ul>

        <p class="strong">Extras</p>

        <p><a href="http://www.cgap.org/publications/competition-mobile-financial-services-lessons-kenya-tanzania"
              target="_blank">World
                Bank/CGAP paper on competition in mobile financial services in East Africa (and the White
                Paper which helped form the basis for Kusha)</a>
        </p>
        <p><a href="http://www.gsma.com/mobilefordevelopment/wp-content/uploads/2016/04/SOTIR_2015.pdf" target="_blank">GSMA,
                2015
                Mobile Money State of the Industry Report</a>
        </p>
        <p><a href="http://finclusion.org/uploads/file/reports/2015%20InterMedia%20FII%20TANZANIA%20Wave%20Report.pdf"
              target="_blank">Financial
                Inclusion Insights: Tanzania</a>
        </p>
        <p>
            <a href="http://www.helix-institute.com/blog/competition-kenyan-digital-finance-market-mobile-money-part-1-3"
               target="_blank">Helix
                Institute, Competition in the Kenyan Digital Finance Market: Mobile Money</a>
        </p>
        <p>
            <a href="http://www.pewglobal.org/2016/02/22/smartphone-ownership-and-internet-usage-continues-to-climb-in-emerging-economies/"
               target="_blank">Smartphone
                Ownership and Internet Usage Continues to Climb in Emerging Economies</a>
        </p>


    </div>
</section>
<!-- Footer -->
<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="12u$">
                <ul class="icons">
                    <li>
                        <a class="icon rounded fa-facebook" href="https://www.facebook.com/Kusha.io"
                           target="_blank"><span class="label">Facebook</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-91408261-1', 'auto');
    ga('send', 'pageview');

</script>
</body>