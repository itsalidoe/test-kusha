(function ($) {

    var amount;
    var option;
    var provider;
    var recipient;
    var is_cheapest;
    var reason;
    var other_desc;

    skel.init({
        reset: 'full',
        breakpoints: {
            global: {
                href: 'css/style.css',
                containers: 1400,
                grid: {gutters: ['2em', 0]}
            },
            xlarge: {
                media: '(max-width: 1680px)',
                href: 'css/style-xlarge.css',
                containers: 1200
            },
            large: {
                media: '(max-width: 1280px)',
                href: 'css/style-large.css',
                containers: 960,
                grid: {gutters: ['1.5em', 0]},
                viewport: {scalable: false}
            },
            medium: {
                media: '(max-width: 980px)',
                href: 'css/style-medium.css',
                containers: '90%!'
            },
            small: {
                media: '(max-width: 736px)',
                href: 'css/style-small.css',
                containers: '90%!',
                grid: {gutters: ['1.25em', 0]}
            },
            xsmall: {
                media: '(max-width: 480px)',
                href: 'css/style-xsmall.css'
            }
        },
        plugins: {
            layers: {
                config: {
                    mode: 'transform'
                },
                navButton: {
                    breakpoints: 'medium',
                    height: '4em',
                    html: '<span class="toggle" data-action="toggleLayer" data-args="navPanel"></span>',
                    position: 'top-left',
                    side: 'top',
                    width: '6em'
                },
                navPanel: {
                    animation: 'overlayX',
                    breakpoints: 'medium',
                    clickToHide: true,
                    height: '100%',
                    hidden: true,
                    html: '<div data-action="moveElement" data-args="nav"></div>',
                    orientation: 'vertical',
                    position: 'top-left',
                    side: 'left',
                    width: 250
                }
            }
        }
    });

    $(function () {

        var $window = $(window),
            $body = $('body');

        // Disable animations/transitions until the page has loaded.
        $body.addClass('is-loading');

        $window.on('load', function () {
            $body.removeClass('is-loading');
        });

        $("#howitworks_menu").click(function () {
            $('html, body').animate({
                scrollTop: $("#howitworks").offset().top
            }, 2000);
        });

        $(".form1").submit(function (e) {
            e.preventDefault();

            if (!checkRequired()) {
                amount = $("#amount").val();
                option = $("#option").val();
                provider = $("#provider").val();
                recipient = $("#recipient").val();
                $('.form1').hide();
                $('.form2').show();
                $("html, body").animate({scrollTop: $("#input-box-id").offset().top}, "slow");
            }
        });

        $('#option').change(function () {
            if (this.value == 'cashout-only') {
                $('#recipient_wrapper').css('visibility', 'hidden');
                $('#recipient').prop('required', false);
                $('#provider_wrapper').css('visibility', 'visible');
                $('#provider').prop('required', true);
            } else {
                $('#recipient_wrapper').css('visibility', 'visible');
                $('#recipient').prop('required', true);
                $('#provider_wrapper').css('visibility', 'visible');
                $('#provider').prop('required', true);

            }
        });


        $('input[type=radio][name=is-cheapest]').change(function () {
            if (this.value == 'yes') {
                $('.options').hide();
                $('#yes-options').fadeIn("slow");
            }
            else if (this.value == 'no') {
                $('.options').hide();
                $('#no-options').fadeIn("slow");
            }
            else if (this.value == 'notsure') {
                $('.options').hide();
                $('#maybe-options').fadeIn("slow");
            }
            $("#get_results").fadeIn("slow");
        });

        $(".form2").submit(function (e) {
            e.preventDefault();
            is_cheapest = $('input[name=is-cheapest]:checked').val();
            reason = $('input[name=reason]:checked').val();

            if (typeof(reason) === "undefined") {
                alert("Please select a reason.");
            } else {
                var otherTxtId = "input[name=other_" + is_cheapest + "]";
                other_desc = $(otherTxtId).val();
                checkPrices();
                $('.form2').hide();
                $('.results').show();
            }
        });
    });

    function checkRequired() {
        var ref = $('input,select').filter('[required]:visible');
        var incomplete = false;
        var field;
        $(ref).each(function () {
            if ($(this).val() == '' || $(this).val() == null) {
                $(this).focus();
                incomplete = true;
                field = $(this).attr('name').substr(0, 1).toUpperCase() + $(this).attr('name').substr(1);
                alert(field + " should not be blank.");
                return false;
            }
        });
        return incomplete;
    }

    function checkPrices() {
        url = "/compare";
        $.post(url, {
            amount: amount,
            option: option,
            from_provider: provider,
            to_provider: recipient,
            is_cheapest: is_cheapest,
            reason: reason,
            other_desc: other_desc
        }, function (data, status) {
            $(".loader").hide();
            fbq('track', 'CompleteRegistration');
            if (data.exists) {

                if (option == 'transfer-only') {
                    header = '<tr><th>Provider</th><th>Transfer Cost</th><th>Total Cost</th></tr>';
                } else if (option == 'cashout-only') {
                    header = '<tr><th>Provider</th><th>Cash Out Cost</th></tr>';
                } else {
                    header = '<tr><th>Provider</th><th>Transfer Cost</th><th>Cash Out Cost</th><th>Total Cost</th></tr>';
                }
                $("#comparison_table").append(header);
                $.each(data.costs, function (i, object) {
                    str = "";
                    $.each(object, function (property, value) {
                        if (property == 'total') {
                            str = str + "<td class='bold'>" + value + "</td>";
                        } else {
                            if (property != 'provider_id') {
                                str = str + "<td>" + value + "</td>";
                            }
                        }
                    });
                    if (i < data.best) {
                        $("#comparison_table").append("<tr class='blue-highlight highlight'>" + str + "</tr>");
                    } else {
                        if (object.provider_id == provider) {
                            $("#comparison_table").append("<tr class='orange-highlight highlight'>" + str + "</tr>");
                        } else {
                            $("#comparison_table").append("<tr>" + str + "</tr>");
                        }
                    }
                });
                if (option != 'cashout-only') {
                    selection = 'You selected: ' + getOptionName(option) + ' Tsh ' + amount + ' to ' + data.recipient;
                } else {
                    selection = 'You selected: ' + getOptionName(option) + ' Tsh ' + amount;
                }
                $("#selection").html(selection);
            } else {
                $("#comparison_table").hide();
                $("#selection").hide();
            }

            $(".display>#message").html(data.message);
            $(".display").fadeIn("slow");

        });
    }

    function getOptionName(option) {
        if (option == 'transfer-only') return "Transfer";
        if (option == 'cashout-only') return "Cash Out";
        if (option == 'transfer-and-cashout') return "Transfer & Cash Out";
    }

})(jQuery);
