<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTariffsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tariffs', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('provider_id')->index();
            $table->integer('lower_limit')->index();
            $table->integer('upper_limit')->index();
            $table->integer('transfer_cost');
            $table->integer('withdrawal_cost');
            $table->integer('internetwork_cost');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tariffs');
    }
}
