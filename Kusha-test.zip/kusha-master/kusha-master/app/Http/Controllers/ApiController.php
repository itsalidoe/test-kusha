<?php

namespace App\Http\Controllers;

use App\Models\Tariff;
use App\Models\Visitor;
use App\Models\Withdrawal;
use Illuminate\Http\Request;

class ApiController extends Controller
{

    public function compare(Request $request)
    {
        if ($request->from_provider == 5 || $request->to_provider == 5) {
            return response()->json($this->respondEmpty());
        }

        if ($request->option == "transfer-only") {
            return response()->json($this->calculateTransfer($request, false));
        } else if ($request->option == "cashout-only") {
            return response()->json($this->calculateCashout($request));
        } else {
            return response()->json($this->calculateTransfer($request, true));
        }

    }

    private function calculateCashout($request)
    {
        $costs = array();
        $i = 0;
        $j = 0;
        $current_cost = 0;

        $withdrawals = Withdrawal::where("lower_limit", "<=", $request->amount)
            ->where("upper_limit", ">=", $request->amount)
            ->join('providers', 'providers.id', '=', 'withdrawals.provider_id')
            ->orderBy('cost', 'ASC')
            ->get();
        foreach ($withdrawals as $withdrawal) {
            $costs[$i]['provider'] = $withdrawal->name;
            $costs[$i]['provider_id'] = $withdrawal->provider_id;
            $costs[$i]['withdrawal_cost'] = $withdrawal->cost;
            $i++;
            if ($withdrawal->provider_id == $request->from_provider) {
                $current_cost = $withdrawal->cost;
            }
            if ($withdrawal->cost == 0) {
                return $this->respondEmpty();
            }
            if ($withdrawal->cost == $costs[0]['withdrawal_cost']){
                $j++;
            }
        }
        if ($i == 0) {
            return $this->respondEmpty();
        } else {
            $array['costs'] = $costs;
            $array['best'] = $j;
            $array['exists'] = true;

            if ($costs[0]['withdrawal_cost'] == $current_cost) {
                $array['message'] = "Congratulations! <span class='blue-highlight highlight'>" . $array['costs'][0]['provider'] .
                    "</span> is the cheapest provider for this transaction";
            } else {
                $array['message'] = "Cash Out using <span class='blue-highlight highlight'>" . $array['costs'][0]['provider'] .
                    "</span> to SAVE Tsh " . ($current_cost - $array['costs'][0]['withdrawal_cost']);
            }
            return $array;
        }
    }

    private function calculateTransfer($request, $cashout)
    {
        $costs = array();
        $i = 0;
        $current_cost = 0;
        $to_provider = "";
        $from_provider = "";

        $tariffs = Tariff::where("lower_limit", "<=", $request->amount)
            ->where("upper_limit", ">=", $request->amount)
            ->join('providers', 'providers.id', '=', 'tariffs.provider_id')
            ->get();

        foreach ($tariffs as $item) {
            $to_networks = explode(',', $item->provider_id2);
            if (!in_array($request->to_provider, $to_networks)) {
                continue;
            }
            $costs[$i]['provider'] = $item->name;
            $costs[$i]['provider_id'] = $item->provider_id;


            if ($item->partnership == 'Y') {
                $withdrawal = Withdrawal::where("lower_limit", "<=", $request->amount)
                    ->where("upper_limit", ">=", $request->amount)
                    ->where("provider_id", "=", $request->to_provider)
                    ->first();
            } else {
                $withdrawal = Withdrawal::where("lower_limit", "<=", $request->amount)
                    ->where("upper_limit", ">=", $request->amount)
                    ->where("provider_id", "=", $item->provider_id)
                    ->first();
            }

            if ($withdrawal->cost == 0) {
                return $this->respondEmpty();
            }

            if ($cashout) {
                $costs[$i]['transfer'] = $item->transfer_cost;
                $costs[$i]['withdrawal'] = $withdrawal->cost;;
                $costs[$i]['total'] = $costs[$i]['transfer'] + $costs[$i]['withdrawal'] + $request->amount;
            } else {
                if ($item->partnership == 'Y') {
                    $costs[$i]['transfer'] = $item->transfer_cost;
                } else {
                    $costs[$i]['transfer'] = $item->transfer_cost + $withdrawal->cost;
                }
                $costs[$i]['total'] = $costs[$i]['transfer'] + $request->amount;
            }


            if ($item->provider_id == $request->from_provider) {
                $current_cost = $costs[$i]['total'];
                $from_provider = $item->name;
            }
            if ($request->to_provider == $item->provider_id) {
                $to_provider = $item->name;
            }
            $i++;
        }

        if ($i == 0) {
            return $this->respondEmpty();
        } else {
            $array['exists'] = true;

            $array['costs'] = array_values(array_sort($costs, function ($value) {
                return $value['total'];
            }));

            $num_best = 0;
            $providerNames = "";
            $isCheapest = false;
            foreach ($array['costs'] as $item) {
                if ($item['total'] == $array['costs'][0]['total']) {
                    $num_best++;
                    if ($providerNames == "") {
                        $providerNames = $item['provider'];
                    } else {
                        $providerNames = $providerNames . ' or ' . $item['provider'];
                    }
                    if ($item['provider_id'] == $request->from_provider) {
                        $isCheapest = true;
                    }
                }
            }
            $array['best'] = $num_best;

            if ($isCheapest) {
                $array['message'] = "Congratulations! <span class='blue-highlight highlight'>" . $from_provider .
                    "</span> is the cheapest provider for this transaction";
            } else {
                $array['message'] = "You can save Tsh " . ($current_cost - $array['costs'][0]['total']) .
                    " by using <span class='blue-highlight highlight'>" . $providerNames . "</span>
                        instead of <span class='orange-highlight highlight'>" . $from_provider . "</span>";

            }
            $array['recipient'] = $to_provider;
            return $array;
        }
    }


    private function respondEmpty()
    {
        $array['exists'] = false;
        $array['message'] = 'Sorry we do not have this information at this time but we are always looking to learn more. <br/><br/>
                    Do you feel you are paying too much? Would you be interested in sharing your costs to help us understand this market? <br/><br/>
                    Send us an <a href="mailto:hello@kusha.io"><u>email</u></a> or contact us through
                    <a href=" https://www.facebook.com/Kusha.io/"><u>Facebook</u></a>. We\'d appreciate the support!';
        return $array;
    }
}
